var markerPosition = 0;
var map;
var baseLayers;
var mycontrol;
var geoJSON = {};

function actualiser(){

	$.getJSON("getZones.php", function( data ) {

		if (typeof geoJSON.zones == 'undefined') {
			geoJSON.zones = L.geoJSON(data, {
				style: function(feature) {
					return {color: feature.properties.color};
				}
			}).addTo(map);

			mycontrol.remove();
			mycontrol = L.control.layers(baseLayers, geoJSON).addTo(map);
		}
	});

	$.getJSON("getData.php", function( data ) {

		if (typeof geoJSON.enquetes !== 'undefined') {
			geoJSON.enquetes.remove();
		}
		geoJSON.enquetes = L.geoJSON(data, {
				pointToLayer: function (feature, latlng) {
					return L.circleMarker(latlng, {
						radius: 5,
						fillColor: feature.properties.color,
						color: "#000",
						weight: 1,
						opacity: 1,
						fillOpacity: 0.8
					});
				}
			}).bindPopup(function (layer) {
				return layer.feature.properties.jour + "<br>" + layer.feature.properties.heure;
			}).addTo(map);

			mycontrol.remove();
			mycontrol = L.control.layers(baseLayers, geoJSON).addTo(map);
	});
}

function ajouter(latitude, longitude) {
	$.getJSON("setData.php?lat="+latitude+"&lng="+longitude);
	actualiser();
}

function maPosition(position) {
	if (markerPosition != 0){
		markerPosition.remove();
	}
	markerPosition = L.marker([position.coords.latitude, position.coords.longitude],{
		icon: L.icon({
			iconUrl: 'images/marker-red.png',
			iconSize: [25, 41],
    		iconAnchor: [0, 50],
    		popupAnchor: [13, -40],
    		shadowSize: [68, 95],
    		shadowAnchor: [22, 94]
		})
	}).bindPopup('votre localisation <br> Précision : '+position.coords.accuracy+' m.<br><button  onClick="ajouter('+position.coords.latitude+', '+position.coords.longitude+')">Nouveau Point ici</button>').addTo(map);

	map.setView([position.coords.latitude, position.coords.longitude], map.getZoom(), { animation: true });

	markerPosition.openPopup();
}

function geolocaliser() {
  	if(navigator.geolocation) {
		navigator.geolocation.getCurrentPosition(maPosition);
	}
}

$(document).ready(function(){

	map = L.map("map").setView([43.6323, 3.8702986], 16);
	geolocaliser();

	var popup = L.popup();

	function onMapClick(e) {
		
    	popup
        	.setLatLng(e.latlng)
        	.setContent("You clicked the map at " + e.latlng.lat + ", " + e.latlng.lng + '.<br><button  onClick="ajouter('+ e.latlng.lat + ", " + e.latlng.lng +')">Nouveau Point ici</button>')
			.openOn(map);
		
	}

	map.on('click', onMapClick);

	var OpenStreetMap_France = L.tileLayer('https://{s}.tile.openstreetmap.fr/osmfr/{z}/{x}/{y}.png', {
		maxZoom: 20,
		attribution: '&copy; Openstreetmap France | &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
	});

	var GeoportailFrance_orthos = L.tileLayer('https://wxs.ign.fr/{apikey}/geoportail/wmts?REQUEST=GetTile&SERVICE=WMTS&VERSION=1.0.0&STYLE={style}&TILEMATRIXSET=PM&FORMAT={format}&LAYER=ORTHOIMAGERY.ORTHOPHOTOS&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}', {
		attribution: '<a target="_blank" href="https://www.geoportail.gouv.fr/">Geoportail France</a>',
		bounds: [[-75, -180], [81, 180]],
		minZoom: 2,
		maxZoom: 19,
		apikey: 'choisirgeoportail',
		format: 'image/jpeg',
		style: 'normal'
	});

	map.addLayer(OpenStreetMap_France);

	// création d’un contrôle des couches pour modifier les couches de fond de plan
	baseLayers = {
		'OpenStreetMap France' : OpenStreetMap_France,
		'Orthophoto IGN' : GeoportailFrance_orthos
	};

	mycontrol = L.control.layers(baseLayers).addTo(map);

	actualiser();

});